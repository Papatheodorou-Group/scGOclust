### This is an R script tangled from 'scGOclust_mouse_fly_gut_vignette.html.asis'
